
import {Gasto} from '../models/gasto';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const URL_API='http://localhost:3000/api/gastos';

@Injectable({
  providedIn: 'root'
})


export class GastoService {

  selectedGasto: Gasto;
  
  gastos:Gasto[]=[];

  constructor(private http: HttpClient){
    this.selectedGasto=new Gasto();
  }

  getGastos(){
    return this.http.get('http://localhost:3000/api/gastos');
  }

  postGasto(Gasto: Gasto){
    return this.http.post(URL_API,Gasto);
  }

  putGasto(gasto: Gasto){
    
    return this.http.put(URL_API+`/${gasto._id}`,gasto);
  }

  deleteGasto(_id:any): Observable<any>{
    return this.http.delete(`${URL_API}/${_id}`);
  }

  
}

