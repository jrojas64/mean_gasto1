import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Gasto } from 'src/app/models/gasto';
import { GastoService } from 'src/app/service/gasto.service';

declare var M:any;
@Component({
  selector: 'app-gasto',
  templateUrl: './gastos.component.html',
  styleUrls: ['./gastos.component.css'],
  providers:[GastoService]
})
export class GastoComponent implements OnInit {

  constructor(public gastosService:GastoService) { }

  ngOnInit(): void {
    this.getGastos();
  }
  getGastos()
  {
    this.gastosService.getGastos()
    .subscribe(res=>{
      this.gastosService.gastos=res as Gasto[];
      console.log(res);
    })
  }
  
  addGasto(form:NgForm)
  {
    if(form.value._id){
        this.gastosService.putGasto(form.value)
        .subscribe(res=>{
        console.log(res);
        this.resetForm(form);
        M.toast({html:'Gasto Actualizado'});
        this.getGastos();
        })
    }else{
    this.gastosService.postGasto(form.value)
    .subscribe(res=>{
      console.log(res);
      this.resetForm(form);
      M.toast({html:'Gasto Guardado'});
      this.getGastos();
      })
    }
  }

  editGasto(gasto: Gasto){
    this.gastosService.selectedGasto=gasto;
    
  }

  editForm(form:NgForm){
    console.log("edit");
    if(form.value._id){
      this.gastosService.putGasto(form.value)
      .subscribe(res=>{
      console.log(res);
      this.resetForm(form);
      M.toast({html:'Gasto Actualizado'});
      this.getGastos();
      })
  }
  }

  deleteGasto(_id: string)
  {
    if(confirm('Estás seguro de quieres borrar?')){
        this.gastosService.deleteGasto(_id)
        .subscribe(res =>{
          console.log(res);
          M.toast({html:'Gasto Eliminado'});
          this.getGastos();        
        });
    }
  }
  resetForm(form?:NgForm)
  {
    if(form)
    {
      form.reset();
      this.gastosService.selectedGasto=new Gasto();
    }
  }
}


